import React from "react";
import Link from "next/link";

const VehicleHistoryPage = () => (
  <div className="min-h-screen bg-gray-50 px-4 py-10 text-gray-900">
    <div className="mx-auto max-w-4xl">
      <p className="text-sm font-semibold text-orange-500">Vehicle history</p>
      <h1 className="text-3xl font-bold">Check vehicle history</h1>
      <p className="mt-2 text-sm text-gray-600">Ownership, insurance, and service highlights in one place.</p>

      <div className="mt-6 rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
        <ul className="list-disc space-y-2 pl-5 text-sm text-gray-700">
          <li>Past owners and RC details</li>
          <li>Insurance validity and claims</li>
          <li>Reported accidents or flood damage (when available)</li>
          <li>Odometer trends and service records</li>
        </ul>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <Link
          href="/buy-car"
          className="inline-flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow hover:bg-blue-700"
        >
          Browse cars
        </Link>
        <Link
          href="/services"
          className="inline-flex items-center justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-800 hover:bg-gray-100"
        >
          Talk to support
        </Link>
      </div>
    </div>
  </div>
);

export default VehicleHistoryPage;
