"use client";
import React, { useState } from "react";
import { useNotification } from "@/context/NotificationContext";
import { Bell, CheckCircle, AlertCircle } from "lucide-react";

const NotificationSettings = () => {
  const {
    preferences,
    updatePreferences,
    requestPermission,
    isSupported,
    fcmToken,
  } = useNotification();
  const [permissionGranted, setPermissionGranted] = useState(
    preferences.enabled
  );
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleEnableNotifications = async () => {
    setLoading(true);
    try {
      const granted = await requestPermission();
      setPermissionGranted(granted);
      if (granted) {
        setShowSuccess(true);
        setTimeout(() => setShowSuccess(false), 3000);
      }
    } catch (error) {
      console.error("Error enabling notifications:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePreference = (
    key: keyof typeof preferences,
    value: boolean
  ) => {
    if (key !== "enabled") {
      updatePreferences({ [key]: value });
    }
  };

  const notificationOptions = [
    {
      key: "appointmentConfirmation",
      label: "Appointment Confirmations",
      description: "Get notified when your appointment is confirmed",
      icon: "📅",
    },
    {
      key: "appointmentReminder",
      label: "Appointment Reminders",
      description: "Receive reminders before your scheduled appointments",
      icon: "⏰",
    },
    {
      key: "bidUpdates",
      label: "Bid Updates",
      description: "Be notified when you receive new bids on your listed cars",
      icon: "💰",
    },
    {
      key: "messagingUpdates",
      label: "New Messages",
      description: "Get alerts for new messages from buyers/sellers",
      icon: "💬",
    },
    {
      key: "priceDropAlerts",
      label: "Price Drop Alerts",
      description: "Know immediately when cars you like drop in price",
      icon: "📉",
    },
    {
      key: "bookingUpdates",
      label: "Booking Updates",
      description: "Updates on your car bookings and payments",
      icon: "✅",
    },
    {
      key: "vehicleInspectionResults",
      label: "Inspection Results",
      description: "Get notified when vehicle inspection reports are ready",
      icon: "🔍",
    },
    {
      key: "newsAndOffers",
      label: "News & Special Offers",
      description: "Stay updated with latest offers and news from CARS24",
      icon: "🎁",
    },
  ];

  if (!isSupported) {
    return (
      <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow">
        <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <AlertCircle className="text-amber-600" />
          <p className="text-amber-800">
            Push notifications are not supported in your browser. Please use a
            modern browser (Chrome, Firefox, Edge, Safari) to enable
            notifications.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Bell className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">
            Notification Settings
          </h1>
        </div>
        <p className="text-gray-600">
          Customize how and when you receive notifications from CARS24
        </p>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
          <CheckCircle className="text-green-600 h-5 w-5" />
          <p className="text-green-800">
            Notifications enabled successfully! You'll now receive real-time
            alerts.
          </p>
        </div>
      )}

      {/* Enable Notifications Section */}
      {!permissionGranted && (
        <div className="mb-8 p-6 bg-blue-50 border-2 border-blue-200 rounded-lg">
          <h2 className="text-xl font-semibold text-blue-900 mb-2">
            Enable Push Notifications
          </h2>
          <p className="text-blue-800 mb-4">
            Allow CARS24 to send you real-time notifications about appointments,
            bids, messages, and more.
          </p>
          <button
            onClick={handleEnableNotifications}
            disabled={loading}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? "Enabling..." : "Enable Notifications"}
          </button>
        </div>
      )}

      {/* Notification Preferences */}
      {permissionGranted && (
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Notification Preferences
          </h2>

          <div className="space-y-4">
            {notificationOptions.map((option) => (
              <div
                key={option.key}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors"
              >
                <div className="flex items-center gap-4 flex-1">
                  <span className="text-2xl">{option.icon}</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {option.label}
                    </h3>
                    <p className="text-sm text-gray-600">{option.description}</p>
                  </div>
                </div>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={
                      preferences[option.key as keyof typeof preferences] as boolean
                    }
                    onChange={(e) =>
                      handleTogglePreference(
                        option.key as keyof typeof preferences,
                        e.target.checked
                      )
                    }
                    className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                  />
                </label>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* FCM Token Info (Dev Only) */}
      {process.env.NODE_ENV === "development" && fcmToken && (
        <div className="mt-8 p-4 bg-gray-100 rounded-lg">
          <p className="text-sm text-gray-600 mb-2 font-mono break-all">
            <strong>FCM Token:</strong> {fcmToken}
          </p>
        </div>
      )}

      {/* Information Section */}
      <div className="mt-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
        <h3 className="font-semibold text-gray-900 mb-3">How Notifications Work</h3>
        <ul className="space-y-2 text-gray-700 text-sm">
          <li>✓ Notifications work even when you close CARS24</li>
          <li>✓ You'll receive alerts on all your devices</li>
          <li>✓ Disable specific types of notifications anytime</li>
          <li>
            ✓ You can manage browser notification permissions in your browser
            settings
          </li>
        </ul>
      </div>
    </div>
  );
};

export default NotificationSettings;
