// firebase-config.ts
let initializeApp: any = null;
let getMessaging: any = null;
let onMessage: any = null;
let app: any = null;
let messaging: any = null;

try {
  const firebaseApp = require("firebase/app");
  const firebaseMessaging = require("firebase/messaging");
  initializeApp = firebaseApp.initializeApp;
  getMessaging = firebaseMessaging.getMessaging;
  onMessage = firebaseMessaging.onMessage;

  // Replace with your Firebase config from Firebase Console
  const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "AIzaSyDummy",
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "cars24-demo.firebaseapp.com",
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "cars24-demo",
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "cars24-demo.appspot.com",
    messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "123456789",
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "1:123456789:web:abcd1234",
  };

  app = initializeApp(firebaseConfig);

  // Initialize Firebase Cloud Messaging
  try {
    messaging = getMessaging(app);
  } catch (error) {
    console.log("Firebase Messaging not available (might be in dev or unsupported browser)");
  }
} catch (error) {
  console.log("Firebase SDK not installed - push notifications will be unavailable");
}

export { app, messaging };

// Set up message listener for foreground notifications
export const setupMessageListener = (callback: (payload: any) => void) => {
  if (messaging && onMessage) {
    onMessage(messaging, (payload: any) => {
      console.log("Message received in foreground:", payload);
      callback(payload);
    });
  }
};

// Request permission and get FCM token
export const requestNotificationPermission = async () => {
  try {
    if (!messaging || !app) {
      console.log("Firebase Messaging not available");
      return null;
    }

    // Check if notifications are supported
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) {
      console.log("Service Workers not supported");
      return null;
    }

    // Check if Notification API is supported
    if (typeof window === "undefined" || !("Notification" in window)) {
      console.log("Notification API not supported");
      return null;
    }

    // Request permission
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      let registration: ServiceWorkerRegistration | undefined;

      // Register service worker (default scope) and ensure it matches current origin/port
      if ("serviceWorker" in navigator) {
        const currentOrigin = window.location.origin;
        try {
          registration = await navigator.serviceWorker.register(
            "/firebase-messaging-sw.js"
          );
          await navigator.serviceWorker.ready;

          // If an old registration exists on a different port/origin, re-register
          if (registration && !registration.scope.startsWith(currentOrigin)) {
            await registration.unregister();
            registration = await navigator.serviceWorker.register(
              "/firebase-messaging-sw.js"
            );
            await navigator.serviceWorker.ready;
            console.log("Re-registered Service Worker for current origin", {
              scope: registration?.scope,
            });
          } else {
            console.log("Service Worker registered", {
              scope: registration?.scope,
            });
          }
        } catch (err) {
          console.error("Service Worker registration failed:", err);
        }
      }

      // Get FCM token (pass SW registration to avoid AbortError)
      try {
        const { getToken } = await import("firebase/messaging");

        // Clean up any stale push subscription before requesting a new token
        if (registration?.pushManager) {
          try {
            const sub = await registration.pushManager.getSubscription();
            if (sub) {
              await sub.unsubscribe();
              console.log("Removed stale push subscription");
            }
          } catch (err) {
            console.warn("Could not clear push subscription", err);
          }
        }

        const token = await getToken(messaging, {
          vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY || "dummy-vapid-key",
          serviceWorkerRegistration: registration,
        });
        
        console.log("FCM Token:", token);
        return token;
      } catch (error) {
        console.error("Failed to get FCM token:", error);
        return null;
      }
    } else {
      console.log("Notification permission denied");
      return null;
    }
  } catch (error) {
    console.error("Error requesting notification permission:", error);
    return null;
  }
};
